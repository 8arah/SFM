
@extends('control_panel.master')

@section('title')
    <title>drone || Create New Drone</title>
@endsection
@section('rapper')


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="{{route('drones.index')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{route('drones.index')}}">Drones</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{route('drones.show',$drone->id)}}">Paths</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
@endsection

@section('style')

@endsection

@section('content')
    @include('control_panel.alert')
    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN VALIDATION STATES-->
            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-gift"></i>Drone paths
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload"></a>
                    </div>
                </div>

                <div class="portlet-body">
                    <div id="map" class="gmaps" style="min-height: 750px;">
                    </div>
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
    {{--<div id="paths">{{$drone->paths}}</div>--}}
@endsection


@section('script')


    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
            defer
    ></script>
    <script>
        function initMap() {
            var markerLatLng = new google.maps.LatLng('{{$drone->latitude}}','{{$drone->longitude}}');

            var map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });
            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });
            var flightPlanCoordinates = [];
            var flightPath = [];
            $.get('{{route('drones.paths',$drone->id)}}',function(data){
                // console.log(data);
                for(x in data) {
                    for(y in data[x]){

                        flightPlanCoordinates[y] = {lat:parseFloat(data[x][y].latitude),lng:parseFloat(data[x][y].longitude)};
                    }
                    flightPath[x] = new google.maps.Polyline({
                        path: flightPlanCoordinates,
                        geodesic: true,
                        strokeColor: '#'+(Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, '0'),
                        strokeOpacity: 1.0,
                        strokeWeight: 2
                    });

                    flightPath[x].setMap(map);
                    flightPlanCoordinates= [];
                }
            });
        }
    </script>

@endsection

