@csrf

<div class="form-body">
    <div class="form-group @if($errors->first('mac')) has-error @endif">
        <label class="control-label col-md-3">Ip</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('mac'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('mac')}}"></i>
                @endif
                <input type="text" name="mac" class="form-control" placeholder="Enter Ip Address" value="{{old('mac',$drone->mac)}}"/>
                @if($errors->first('mac'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('mac')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('heat')) has-error @endif">
        <label class="control-label col-md-3">Max Heat (C)</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('heat'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('heat')}}"></i>
                @endif
                <input type="text" name="heat" class="form-control" placeholder="Enter Drone Heat" value="{{old('heat',$drone->heat)}}"/>
                @if($errors->first('heat'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('heat')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('buttery')) has-error @endif">
        <label class="control-label col-md-3">Battery (%)</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('buttery'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('buttery')}}"></i>
                @endif
                <input type="text" name="buttery" class="form-control" placeholder="Enter battery level" value="{{old('buttery',$drone->buttery)}}"/>
                @if($errors->first('buttery'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('buttery')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('weight')) has-error @endif">
        <label class="control-label col-md-3">Max PayLoad (G)</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('weight'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('weight')}}"></i>
                @endif
                <input type="text" name="weight" class="form-control" placeholder="Enter Weight : Max 3000 Grams" value="{{old('weight',$drone->weight)}}"/>
                @if($errors->first('weight'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('weight')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="form-body">
    <div class="form-group @if($errors->first('start_end_point_id')) has-error @endif">
        <label class="control-label col-md-3">Station Point</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    @if($errors->first('start_end_point_id'))
                        <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('weight')}}"></i>
                    @endif
                    <select name="start_end_point_id" class="form-control">
                        @foreach($start_points as $start_point)
                            <option value="{{$start_point->id}}" @if($start_point->drone_count) selected @endif>{{$start_point->name}}</option>
                        @endforeach
                    </select>
                    @if($errors->first('start_end_point_id'))
                        <span id="name-error" class="help-block help-block-error">{{$errors->first('start_end_point_id')}}</span>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="id" value="{{$drone->id}}">
<input type="hidden" name="lat" id="lat" value="{{$drone->latitude}}">
<input type="hidden" name="lng" id="lng" value="{{$drone->longitude}}">


<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
        defer
></script>
<script>
function initMap() {
    var markerLatLng = new google.maps.LatLng('{{$drone->latitude}}','{{$drone->longitude}}');

    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16,
        center: markerLatLng,
        mapTypeId: "terrain"
    });

    var marker = new google.maps.Marker({
        position: markerLatLng,
        map: map, // handle of the map
        draggable:true
    });
    map.addListener('click',function(event){
        console.log(event.latLng.lat());
        markerLatLng = event.latLng;
        if(typeof (marker) === 'object'){
            marker.setMap(null);
        }
        marker = new google.maps.Marker({
            position: markerLatLng,
            map: map, // handle of the map
            draggable:true
        });
        document.getElementById('lat').value = event.latLng.lat();
        document.getElementById('lng').value = event.latLng.lng();
    });

    // if(typeof (marker) === 'object') {
    marker.addListener('drag',function (event) {
            console.log(event,marker);
            document.getElementById('lat').value = event.latLng.lat();
            document.getElementById('lng').value = event.latLng.lng();
    });
    // }
}
</script>

