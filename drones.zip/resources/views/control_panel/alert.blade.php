    @if(session('msg'))
        <div class="Metronic-alerts alert alert-{{ session('status') }} fade in">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
            {{ session('msg') }}
        </div>
    @endif