@csrf
<div class="form-body">
    <div class="form-group">
        <label class="control-label col-md-3">Enter your Location</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    <select class="form-control" id="selectBox" onclick="setLatLng()">
                    @foreach($station_points as $point)
                        <option @if($point->name == $default_station_name) selected @endif data-lat = "{{$point->lat}}" data-lng = "{{$point->lng}}" data-station-name = "{{$point->name}}">{{$point->name}}</option>
                    @endforeach
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('lat')||$errors->first('lng')) has-error @endif">
        <label class="control-label col-md-3">Enter your distination</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    <div id="map" class="gmaps">
                    </div>
                    @if($errors->first('lat')||$errors->first('lng'))
                        <span id="name-error" class="help-block help-block-error">Please select a valid starting point</span>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('details')) has-error @endif">
        <label class="control-label col-md-3">Details</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('details'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('details')}}"></i>
                @endif
                <textarea name="details" rows="7" class="form-control" placeholder="Enter your order details"/>{{old('details',$path->details)}}</textarea>
                @if($errors->first('details'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('details')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="id" value="{{$path->id}}">
<input type="hidden" name="lat" id="lat" value="{{$default_lat}}">
<input type="hidden" name="lng" id="lng" value="{{$default_lng}}">
<input type="hidden" name="station_name" id="station_name" value="{{$default_station_name}}">


<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
        defer
></script>
<script>
function initMap() {
    var markerLatLng = new google.maps.LatLng(parseFloat(document.getElementById('lat').value),parseFloat(document.getElementById('lng').value));
    // console.log(parseFloat(document.getElementById('lat').value),parseFloat(document.getElementById('lng').value));
    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16,
        center: markerLatLng,
        mapTypeId: "terrain"
    });

    var marker = new google.maps.Marker({
        position: markerLatLng,
        map: map, // handle of the map
        draggable:true
    });
    // map.addListener('click',function(event){
    //     console.log(event.latLng.lat());
    //     markerLatLng = event.latLng;
    //     if(typeof (marker) === 'object'){
    //         marker.setMap(null);
    //     }
    //     marker = new google.maps.Marker({
    //         position: markerLatLng,
    //         map: map, // handle of the map
    //         draggable:true
    //     });
    //     document.getElementById('lat').value = event.latLng.lat();
    //     document.getElementById('lng').value = event.latLng.lng();
    // });
    //
    // // if(typeof (marker) === 'object') {
    // marker.addListener('drag',function (event) {
    //         console.log(event,marker);
    //         document.getElementById('lat').value = event.latLng.lat();
    //         document.getElementById('lng').value = event.latLng.lng();
    // });
    // }
}
function setLatLng() {
    var selectBox = document.getElementById('selectBox');
    var option = selectBox.options[selectBox.selectedIndex];
    document.getElementById('lat').value = option.getAttribute("data-lat");
    document.getElementById('lng').value = option.getAttribute("data-lng");
    document.getElementById('station_name').value = option.getAttribute("data-station-name");
    console.log(document.getElementById('lat').value,document.getElementById('lng').value);
    initMap();
}
</script>

