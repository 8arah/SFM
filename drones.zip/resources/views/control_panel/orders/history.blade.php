
@extends('control_panel.master')

@section('title')
    <title>order || History</title>
@endsection

@section('title_head')
    <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1>Orders || <small> History </small></h1>
        </div>
        <!-- END PAGE TITLE -->
    </div>
@endsection

@section('rapper')


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="{{route('orders.index')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="#">Orders</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
@endsection

@section('style')


@endsection

@section('content')

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet box grey-cascade">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-globe"></i>History Orders
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload">
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-6">
                                <div class="btn-group pull-right">
                                    {{--<a href="{{route('orders.create')}}" id="sample_editable_1_new" class="btn green">--}}
                                        {{--<i class="fa fa-plus"></i>--}}
                                    {{--</a>--}}
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover" id="sample_1">
                        <thead>
                        <tr>
                            <th class="table-checkbox">
                                Destination
                            </th>
                            <th>
                                Details
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Create At
                            </th>
                            <th>
                                Drone Name
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($orders as $order)
                            <tr class="odd gradeX" @if($order->deleted_at) style="background-color: #f39e9e;" @endif>
                                <td>
                                    {!! $order->distination_point !!}
                                </td>
                                <td class="center">
                                    {{ $order->details }}
                                </td>
                                <td class="center">
                                    {!! $order->status_value !!}
                                </td>
                                <td class="center">
                                    {{ $order->created_at }}
                                </td>
                                <td class="center">
                                    {{ $order->drone_name }}
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
@endsection



@section('script')
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&libraries=&v=weekly"
            defer
    ></script>
    <script src="{{asset('sweetalert/sweetalert2.all.min.js')}}"></script>
    <!-- page script -->
    <script>
        function deleteItem(obj,order_id){
            // console.log(obj.parentElement.parentElement);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    var fd = new FormData();
                    fd.append( '_token','{{csrf_token()}}');
                    fd.append( '_method','DELETE');

                    $.ajax({
                        url: "/orders/"+order_id,
                        data: fd,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        success: function(data){
                            if(!data.errors){
                                obj.parentElement.parentElement.parentElement.parentElement.removeChild(obj.parentElement.parentElement.parentElement);
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    data.msg,
                                    'success'
                                )
                            }else{
                                swalWithBootstrapButtons.fire(
                                    'Error!',
                                    data.msg,
                                    'danger'
                                )
                            }
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        }
        function ShowDistinationPoint(lat,lng,path_id){
            // document.getElementById("modal_body").value = '';
            var markerLatLng = new google.maps.LatLng(lat,lng);

            var map = new google.maps.Map(document.getElementById("modal_body"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });

            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });
            var flightPlanCoordinates = [];
            var flightPath = {};
            $.get('/getOrderPath/'+path_id,function(data){
                console.log(data);
                for(x in data) {
                    flightPlanCoordinates[x] = {lat:parseFloat(data[x].lat),lng:parseFloat(data[x].lng)};
                }
                flightPath = new google.maps.Polyline({
                    path: flightPlanCoordinates,
                    geodesic: true,
                    strokeColor: '#'+(Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, '0'),
                    strokeOpacity: 1.0,
                    strokeWeight: 2
                });
                flightPath.setMap(map);
            });
        }

    </script>
@endsection

