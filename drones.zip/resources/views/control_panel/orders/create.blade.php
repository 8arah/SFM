
@extends('control_panel.master')

@section('title')
    <title>order || Create New order</title>
@endsection
@section('rapper')


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="{{route('orders.index')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{route('orders.index')}}">orders</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{route('orders.create')}}">Create</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
@endsection

@section('style')

@endsection

@section('content')
    @include('control_panel.alert')
    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN VALIDATION STATES-->
            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-gift"></i>Create order
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload"></a>
                    </div>
                </div>
                <div class="portlet-body form">
                    <!-- BEGIN FORM-->
                    <form action="{{route('orders.store')}}" method="post" class="form-horizontal">
                        @include('control_panel.orders.form')
                        <div class="form-actions">
                            <div class="row">
                                <div class="col-md-offset-3 col-md-9">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
@endsection


@section('script')

@endsection

