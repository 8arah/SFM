
@extends('control_panel.master')

@section('title')
    <title>start point || all</title>
@endsection

@section('title_head')
    <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1>start points || <small> ALL </small></h1>
        </div>
        <!-- END PAGE TITLE -->
    </div>
@endsection

@section('rapper')


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="{{route('start_points.index')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="#">start points</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
@endsection

@section('style')


@endsection

@section('content')

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet box grey-cascade">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-globe"></i>All start points
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload">
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-6">
                                <div class="btn-group pull-right">
                                    <a href="{{route('start_points.create')}}" id="sample_editable_1_new" class="btn green">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover" id="sample_1">
                        <thead>
                        <tr>
                            <th>
                                name
                            </th>
                            <th>
                                map
                            </th>
                            <th>
                                update
                            </th>
                            <th>
                                delete
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($start_points as $start_point)
                            <tr class="odd gradeX">
                                <td>
                                    {{$start_point->name}}
                                </td>
                                <td>
                                    {!! $start_point->starting_point !!}
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="{{route('start_points.edit',$start_point->id)}}" id="sample_editable_1_new" class="btn green">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        {!! $start_point->delete_button !!}
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
    <input type="hidden" id="new_path_id" value="0">
@endsection



@section('script')
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&libraries=&v=weekly"
            defer
    ></script>
    <script src="{{asset('sweetalert/sweetalert2.all.min.js')}}"></script>
    <!-- page script -->
    <script>
        function deleteItem(obj,start_point_id){
            // console.log(obj.parentElement.parentElement);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    var fd = new FormData();
                    fd.append( '_token','{{csrf_token()}}');
                    fd.append( '_method','DELETE');

                    $.ajax({
                        url: start_point_id,
                        data: fd,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        success: function(data){
                            console.log(data);
                            if(!data.errors){
                                obj.parentElement.parentElement.parentElement.parentElement.removeChild(obj.parentElement.parentElement.parentElement);
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    data.msg,
                                    'success'
                                )
                            }else{
                                swalWithBootstrapButtons.fire(
                                    'Error!',
                                    data.msg,
                                    'danger'
                                )
                            }
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        }
        function ShowStartingPoint(lat,lng){
            // document.getElementById("modal_body").value = '';
            var markerLatLng = new google.maps.LatLng(lat,lng);

            var map = new google.maps.Map(document.getElementById("modal_body"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });

            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });
        }
    </script>


@endsection

