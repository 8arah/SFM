@csrf

<div class="form-body">
    <div class="form-group @if($errors->first('name')) has-error @endif">
        <label class="control-label col-md-3">Name</label>
        <div class="col-md-8">
            <div class="input-icon right">
                @if($errors->first('name'))
                    <i class="fa fa-warning tooltips" data-original-title="{{$errors->first('name')}}"></i>
                @endif
                <input type="text" name="name" class="form-control" placeholder="Enter name" value="{{old('name',$start_point->name)}}"/>
                @if($errors->first('name'))
                    <span id="name-error" class="help-block help-block-error">{{$errors->first('name')}}</span>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group @if($errors->first('lat')||$errors->first('lng')) has-error @endif">
        <label class="control-label col-md-3">Starting point</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    <div id="map" class="gmaps">
                    </div>
                    @if($errors->first('lat')||$errors->first('lng'))
                        <span id="name-error" class="help-block help-block-error">Please select a valid starting point</span>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="id" value="{{$start_point->id}}">
<input type="hidden" name="lat" id="lat" value="{{$start_point->latitude}}">
<input type="hidden" name="lng" id="lng" value="{{$start_point->longitude}}">


<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
        defer
></script>
<script>
function initMap() {
    var markerLatLng = new google.maps.LatLng('{{$start_point->latitude}}','{{$start_point->longitude}}');

    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16,
        center: markerLatLng,
        mapTypeId: "terrain"
    });

    var marker = new google.maps.Marker({
        position: markerLatLng,
        map: map, // handle of the map
        draggable:true
    });
    map.addListener('click',function(event){
        console.log(event.latLng.lat(),event.latLng.lng());
        markerLatLng = event.latLng;
        if(typeof (marker) === 'object'){
            marker.setMap(null);
        }
        marker = new google.maps.Marker({
            position: markerLatLng,
            map: map, // handle of the map
            draggable:true
        });
        document.getElementById('lat').value = event.latLng.lat();
        document.getElementById('lng').value = event.latLng.lng();
    });

    // if(typeof (marker) === 'object') {
    marker.addListener('drag',function (event) {
            console.log(event,marker);
            document.getElementById('lat').value = event.latLng.lat();
            document.getElementById('lng').value = event.latLng.lng();
    });
    // }
}
</script>

