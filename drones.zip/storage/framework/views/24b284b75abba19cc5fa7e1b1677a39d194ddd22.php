<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Drone Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    <meta name="author" content="..." />

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />

    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/bootstrap.css')); ?>">
    <!-- Owl Carousel  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/owl.theme.default.min.css')); ?>">
    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/animate.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/all.css')); ?>">
    <!-- Font Google -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <!-- Theme style  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/style.css')); ?>">

    <!-- Theme Editor-->
    <!--<link rel="stylesheet" href="<?php echo e(asset('landing/css/blackash.css')); ?>">-->

</head>
<body>


<div id="page-wrap">


    <!-- ====================================================== Header ================================================= -->

    <div id="na-header-wrapper">

        <div class="site-header header-fixed navbar navbar-expand-lg main-navbar-nav navbar-light">
            <div class="container">
                <a id="logo" class="logo" href="#">
                    <img class="logo-img" src="<?php echo e(asset('landing/img/logo.png')); ?>" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="icon-toggler"></i>
                    <i class="icon-toggler"></i>
                    <i class="icon-toggler"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav nav-items-center ml-auto mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#" >Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="$('#na-introduce').goTo();return false;">Introduction</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="$('#na-guide').goTo();return false;">Our Works</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="$('#na-review').goTo();return false;">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="$('#na-form').goTo();return false;">Contact Us</a>
                        </li>
                    </ul>
                    <div class="btn-header">
                        <?php if(auth()->guard()->guest()): ?>
                            <a class="btn-link" href="<?php echo e(route('login')); ?>">Login</a>
                            <a class="btn-link" href="<?php echo e(route('register')); ?>">Register</a>
                        <?php else: ?>
                            <a class="btn-link" href="<?php echo e(route('drones.index')); ?>">Drones</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-header-hoder"></div>
        <!-- Slider =================================================== -->
        <div class="container na-slider">
            <span class="sub-title animated fadeInDown wow" data-wow-delay="0.2s">Flying will get better</span>
            <h1 class="animated fadeIn wow" data-wow-delay="0.4s">Smart Fleet Management<br>Try it now!</h1>

            <img class="image-product animated fadeInUp wow" data-wow-delay="1s" src="<?php echo e(asset('landing/img/product.png')); ?>" alt="Product">
        </div>

        <div class="modal-video modal fade video-intro" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-videos" width="1000" height="562" src="https://www.youtube.com/embed/uF-WXHwzURs?start=2"  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>


    </div>



    <!-- ==========================================================================================================
                                                     ADVANTAGES
         ========================================================================================================== -->

    <div id="na-introduce" class="na-advantages-outer">
        <div class="container">
            <h2 class="box-title animated fadeIn wow" data-wow-delay="0.2s"> The idea of our project is to create a system
                to regulate the flight of drones in the sky and prevent collisions between them, Through advanced artificial intelligence
                algorithms to determine the paths that the plane run before its launch without human intervention.</h2>

        </div>
    </div>


    <!-- ==========================================================================================================
                                                      Our Works
         ========================================================================================================== -->

    <div id="na-guide" class="na-guide"><br><br>
        <h2 class="box-title center animated fadeIn wow" data-wow-delay="0.2s"> Our Works</h2>
        <p class="center animated fadeIn wow" data-wow-delay="0.5s">Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam praesent commodo cursus magna.</p>
        <div class="container-full animated fadeIn wow" data-wow-delay="0.6s">
            <div class="owl-carousel owl-theme" data-number="6" data-number-table="4"  data-number-mintable="3" data-number-mobile="2" data-dots="false" data-arrows="false" data-loop="true">

                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video1.jpg')); ?>" alt="video1">
                    </div>
                </div>
                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video2.jpg')); ?>" alt="video1">
                    </div>
                </div>
                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video3.jpg')); ?>" alt="video1">
                    </div>
                </div>
                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video4.jpg')); ?>" alt="video1">
                    </div>
                </div>
                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video5.jpg')); ?>" alt="video1">
                        <button class="btn-play-grid" data-toggle="modal" data-target=".guide-video5"><i class="fa fa-play"></i></button>
                    </div>
                    <!-- <div class="grid-video clearfix">
                        <a class="grid-title" href="#" target="_blank">The controller to an Apple device will not work ?</a>
                        <span class="time">02:45</span>
                    </div> -->

                </div>
                <div class="item">
                    <div class="image-video">
                        <img src="<?php echo e(asset('landing/img/video6.jpg')); ?>" alt="video1">
                        <button class="btn-play-grid" data-toggle="modal" data-target=".guide-video6"><i class="fa fa-play"></i></button>
                    </div>

                </div>
            </div>


        </div>

        <!--video guide 1-->
        <div class="modal-video modal fade guide-video1" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video1" width="1000" height="562" src=".."  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--video guide 2-->
        <div class="modal-video modal fade guide-video2" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video2" width="1000" height="562" src=".."  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--video guide 3-->
        <div class="modal-video modal fade guide-video3" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video3" width="1000" height="562" src=".."  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--video guide 4-->
        <div class="modal-video modal fade guide-video4" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video4" width="1000" height="562" src=".."  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--video guide 5-->
        <div class="modal-video modal fade guide-video5" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video5" width="1000" height="562" src=".."  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--video guide 6-->
        <div class="modal-video modal fade guide-video6" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="embed-responsive-16by9  embed-responsive-16by9 na-videos">
                        <iframe id="na-video6" width="1000" height="562" src="https://www.youtube.com/embed/7vmMm6VldkI?start=2"  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ==========================================================================================================
                                                      FEATURES
         ========================================================================================================== -->

    <div class="curved-bg-div wow animated fadeIn" data-wow-delay="0.15s"></div>
    <div id="na-features" class="na-features">
        <div class="container">

            <div class="na-features-grid-columns clearfix">
                <div class="box-md-6 img-box wow animated fadeInLeft clearfix" data-wow-delay="0.22s">
                    <img class="img-float-left" src="<?php echo e(asset('landing/img/features1.jpg')); ?>" alt="features1">
                    <div class="span-dots">
                        <div class="circle" style="animation-delay: -3s"></div>
                        <div class="circle" style="animation-delay: -2s"></div>
                        <div class="circle" style="animation-delay: -1s"></div>
                        <div class="circle" style="animation-delay: 0s"></div>
                    </div>
                    <p class="des wow animated fadeInDown" data-wow-delay="0.5s">Obstacle sensing systems are active during normal flight, RTH, and all Intelligent Flight Modes. These sensors are core, which provides a full range.</p>
                </div>
                <div class="box-md-6 des-box des-box-right wow animated fadeInRight" data-wow-delay="0.44s">
                    <h3 class="sub-title">Powerful remote controller</h3>
                    <p>Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone. </p>
                </div>
            </div>
            <div class="na-features-grid-columns  box-2 clearfix">
                <div class="box-md-6 des-box des-box-left  wow animated fadeInLeft" data-wow-delay="0.8s">
                    <h3 class="sub-title">Manufacturer Information</h3>
                    <p>Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone Power Drone.</p>

                </div>
                <div class="box-md-6 img-box wow animated fadeInRight" data-wow-delay="0.12s">
                    <img class="img-float-right" src="<?php echo e(asset('landing/img/features2.jpg')); ?>" alt="features2">
                </div>
            </div> <!-- row -->


        </div>
    </div>


    <!-- ==========================================================================================================
                                                      REVIEWS
         ========================================================================================================== -->

    <div id="na-review" class="na-reviews"><br><br>
        <h2 class="box-title center animated fadeIn wow" data-wow-delay="0.2s">About Us</h2>
        <p class="center animated fadeIn wow" data-wow-delay="0.5s">We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are We are.</p>
        <div class="container animated fadeIn wow" data-wow-delay="0.8s">
            <div class="owl-carousel owl-theme" data-number="3" data-number-table="3"  data-number-mintable="2"  data-number-mobile="1" data-dots="true" data-arrows="false" data-loop="true">
                <div class="item wow fadeIn animated" data-wow-delay="0.25s">
                    <div class="item-author" style="border-top:none;margin-top:0;padding:0;">
                        <img class="img-author" src="<?php echo e(asset('landing/img/review3.jpg')); ?>" alt="review1">
                        <div class="about-author">
                            <span class="name-author">Maha Alsulaim</span>
                            <span class="position-author">Electrical Engineering Student</span>
                        </div>
                    </div><br>
                    <p class="testimonial-desc">Nullam quis risus eget urna mollis ornare vel eu leo. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam.</p>
                </div>
                <div class="item wow fadeIn animated" data-wow-delay="0.25s">
                    <div class="item-author" style="border-top:none;margin-top:0;padding:0;">
                        <img class="img-author" src="<?php echo e(asset('landing/img/review3.jpg')); ?>" alt="review1">
                        <div class="about-author">
                            <span class="name-author">Sarah Alomran</span>
                            <span class="position-author">Electrical Engineering Student</span>
                        </div>
                    </div><br>
                    <p class="testimonial-desc">Nullam quis risus eget urna mollis ornare vel eu leo. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam.</p>
                </div>
                <div class="item wow fadeIn animated" data-wow-delay="0.25s">
                    <div class="item-author" style="border-top:none;margin-top:0;padding:0;">
                        <img class="img-author" src="<?php echo e(asset('landing/img/review3.jpg')); ?>" alt="review1">
                        <div class="about-author">
                            <span class="name-author">Nora Alfaris</span>
                            <span class="position-author">Information Technology Student</span>
                        </div>
                    </div><br>
                    <p class="testimonial-desc">Nullam quis risus eget urna mollis ornare vel eu leo. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam.</p>
                </div>
                <div class="item wow fadeIn animated" data-wow-delay="0.25s">
                    <div class="item-author" style="border-top:none;margin-top:0;padding:0;">
                        <img class="img-author" src="<?php echo e(asset('landing/img/review3.jpg')); ?>" alt="review1">
                        <div class="about-author">
                            <span class="name-author">Raghad Aljumah</span>
                            <span class="position-author">Electrical Engineering Student</span>
                        </div>
                    </div><br>
                    <p class="testimonial-desc">Nullam quis risus eget urna mollis ornare vel eu leo. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam.</p>
                </div>
                <div class="item wow fadeIn animated" data-wow-delay="0.25s">
                    <div class="item-author" style="border-top:none;margin-top:0;padding:0;">
                        <img class="img-author" src="<?php echo e(asset('landing/img/review3.jpg')); ?>" alt="review1">
                        <div class="about-author">
                            <span class="name-author">Sara Alkuait</span>
                            <span class="position-author">Industrial Engineering Student</span>
                        </div>
                    </div><br>
                    <p class="testimonial-desc">Nullam quis risus eget urna mollis ornare vel eu leo. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ==========================================================================================================
                                                      LIST PRODUCTS
         ========================================================================================================== -->

    <!-- <div id="na-products" class="na-products">
        <h2 class="box-title center animated fadeIn wow" data-wow-delay="0.2s">Drone Products</h2>
        <div class="container animated fadeIn wow" data-wow-delay="0.5s"	>
            <div class="owl-carousel owl-theme" data-number="4" data-number-table="3"  data-number-mintable="2"  data-number-mobile="2" data-dots="true" data-arrows="false" data-loop="true">

                <div class="item wow">
                    <img class="img-product" src="<?php echo e(asset('landing/img/product-1.jpg')); ?>" alt="product 1">
                    <div class="name-product">Quick Swap Smart Battery Premium Quality</div>
                    <div class="price-product">$46.00</div>
                </div>
                <div class="item wow">
                    <img class="img-product" src="<?php echo e(asset('landing/img/product-2.jpg')); ?>" alt="product 2">
                    <div class="name-product">Zenmuse A7 Gimbal For Sony A7s 500</div>
                    <div class="price-product">$69.00</div>
                </div>
                <div class="item wow">
                    <img class="img-product" src="<?php echo e(asset('landing/img/product-3.jpg')); ?>" alt="product 3">
                    <div class="name-product">Zenmuse X5 Gimbal And Camera Silhouette</div>
                    <div class="price-product">$46.00</div>
                </div>
                <div class="item wow">
                    <img class="img-product" src="<?php echo e(asset('landing/img/product-4.jpg')); ?>" alt="product 4">
                    <div class="name-product">Inspire 1 – Zenmuse X3 Gimbal Adapter</div>
                    <div class="price-product">$52.00</div>
                </div>
                <div class="item wow">
                    <img class="img-product" src="<?php echo e(asset('landing/img/product-5.jpg')); ?>" alt="product 5">
                    <div class="name-product">Inspire 1 Quadcopter – 4K Camera Premium Quality</div>
                    <div class="price-product">$54.00</div>
                </div>

            </div>
        </div>
    </div> -->

    <!-- ==========================================================================================================
                                                      Request Form
         ========================================================================================================== -->
    <div id="na-form" class="na-form">
        <div class="container">
            <div class="row">

                <div class="col-md-6"><br><br><br>
                    <h2 class="box-title animated fadeInLeft wow" data-wow-delay="0.2s">Get In Touch</h2>
                    <p class="animated fadeInLeft wow" data-wow-delay="0.2s">Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam praesent commodo cursus magna.</p>
                    <form class="form-request nimated fadeInLeft wow" data-wow-delay="0.4s" method="post" name="contact_form" action="mailto:someone@example.com">
                        <input type="text" name="name" placeholder="Name:">
                        <input type="text" name="email" placeholder="Email:">
                        <input type="text" name="phone" placeholder="Phone:">
                        <textarea name="message" placeholder="Address:"></textarea>
                        <input  class="btn-submit" type="submit" value="Get Started Now">
                    </form>
                </div>
                <div class="col-md-6 padding-let-sm"><br><br><br>
                    <h2 class="box-title animated fadeInRight wow" data-wow-delay="0.2s">Contact Information</h2>
                    <p class="animated fadeInRight wow" data-wow-delay="0.2s">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies pretium nisi quis interdum. Duis elit purus, suscipit et quam.</p>
                    <div class="ground-information animated fadeInRight wow" data-wow-delay="0.4s">

                        <div class="item-ico">
                            <i class="fa fa-envelope"></i>
                            <div class="ground-text">
                                <span class="name">Email</span>
                                <span class="des">yourmail@mail.com</span>
                            </div>
                        </div>
                        <div class="item-ico">
                            <i class="fa fa-phone"></i>
                            <div class="ground-text">
                                <span class="name">Phone</span>
                                <span class="des">+(2200) 785 111 00</span>
                            </div>
                        </div>
                        <div class="item-ico">
                            <i class="fa fa-map-marker-alt"></i>
                            <div class="ground-text">
                                <span class="name">Address</span>
                                <span class="des">96 Jakubowski Flat Apt. 027</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


</div> <!-- main page wrapper -->

<script src="<?php echo e(asset('landing/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/main.js')); ?>"></script>

<!-- Theme Editor-->
<!--<script src="js/blackash-editor.js"></script>-->
<!--<script src="js/getcolor.js"></script>-->

<input style="top: 340px; opacity: 0; border: 5px solid white; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px inset, rgba(0, 0, 0, 0.1) 0px 0px 16px; padding: 15px; background: rgb(255, 41, 184) none repeat scroll 0% 0%; margin: 0px 0px 10px; position: fixed; left: 20px; color: rgb(255, 255, 255); height: 40px; z-index: 9999;"
       class="jscolor colorpcikewebjs" value="FF29B8" autocomplete="off">
</body>
</html><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/landing_page/index.blade.php ENDPATH**/ ?>