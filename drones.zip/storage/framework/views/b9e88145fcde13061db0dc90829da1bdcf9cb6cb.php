    <?php if(session('msg')): ?>
        <div class="Metronic-alerts alert alert-<?php echo e(session('status')); ?> fade in">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
            <?php echo e(session('msg')); ?>

        </div>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/alert.blade.php ENDPATH**/ ?>