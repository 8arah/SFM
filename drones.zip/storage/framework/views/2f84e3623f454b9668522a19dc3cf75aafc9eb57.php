


<?php $__env->startSection('title'); ?>
    <title>end point || update New end point</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('rapper'); ?>


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="<?php echo e(route('end_points.index')); ?>">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="<?php echo e(route('end_points.index')); ?>">end points</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="<?php echo e(route('end_points.edit',$end_point->id)); ?>">edit</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('control_panel.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN VALIDATION STATES-->
            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-gift"></i>update end point
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload"></a>
                    </div>
                </div>
                <div class="portlet-body form">
                    <!-- BEGIN FORM-->
                    <form action="<?php echo e(route('end_points.update',$end_point->id)); ?>" method="post" class="form-horizontal">
                        <?php echo $__env->make('control_panel.end_points.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input name="_method" value="PUT" type="hidden"/>
                        <div class="form-actions">
                            <div class="row">
                                <div class="col-md-offset-3 col-md-9">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- END FORM-->
                </div>
            </div>
            <!-- END VALIDATION STATES-->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/end_points/update.blade.php ENDPATH**/ ?>