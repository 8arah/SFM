<?php echo csrf_field(); ?>

<div class="form-body">
    <div class="form-group <?php if($errors->first('mac')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">Mac</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <?php if($errors->first('mac')): ?>
                    <i class="fa fa-warning tooltips" data-original-title="<?php echo e($errors->first('mac')); ?>"></i>
                <?php endif; ?>
                <input type="text" name="mac" class="form-control" placeholder="Enter Mac Address" value="<?php echo e(old('mac',$drone->mac)); ?>"/>
                <?php if($errors->first('mac')): ?>
                    <span id="name-error" class="help-block help-block-error"><?php echo e($errors->first('mac')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group <?php if($errors->first('buttery')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">buttery</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <?php if($errors->first('buttery')): ?>
                    <i class="fa fa-warning tooltips" data-original-title="<?php echo e($errors->first('buttery')); ?>"></i>
                <?php endif; ?>
                <input type="text" name="buttery" class="form-control" placeholder="Enter buttery level" value="<?php echo e(old('buttery',$drone->buttery)); ?>"/>
                <?php if($errors->first('buttery')): ?>
                    <span id="name-error" class="help-block help-block-error"><?php echo e($errors->first('buttery')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group <?php if($errors->first('weight')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">weight</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <?php if($errors->first('weight')): ?>
                    <i class="fa fa-warning tooltips" data-original-title="<?php echo e($errors->first('weight')); ?>"></i>
                <?php endif; ?>
                <input type="text" name="weight" class="form-control" placeholder="Enter weight" value="<?php echo e(old('weight',$drone->weight)); ?>"/>
                <?php if($errors->first('weight')): ?>
                    <span id="name-error" class="help-block help-block-error"><?php echo e($errors->first('weight')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="form-body">
    <div class="form-group <?php if($errors->first('start_end_point_id')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">Starting point</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    <?php if($errors->first('start_end_point_id')): ?>
                        <i class="fa fa-warning tooltips" data-original-title="<?php echo e($errors->first('weight')); ?>"></i>
                    <?php endif; ?>
                    <select name="start_end_point_id" class="form-control">
                        <?php $__currentLoopData = $start_points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $start_point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($start_point->id); ?>" <?php if($start_point->drone_count): ?> selected <?php endif; ?>><?php echo e($start_point->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->first('start_end_point_id')): ?>
                        <span id="name-error" class="help-block help-block-error"><?php echo e($errors->first('start_end_point_id')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" name="id" value="<?php echo e($drone->id); ?>">
<input type="hidden" name="lat" id="lat" value="<?php echo e($drone->latitude); ?>">
<input type="hidden" name="lng" id="lng" value="<?php echo e($drone->longitude); ?>">


<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
        defer
></script>
<script>
function initMap() {
    var markerLatLng = new google.maps.LatLng('<?php echo e($drone->latitude); ?>','<?php echo e($drone->longitude); ?>');

    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16,
        center: markerLatLng,
        mapTypeId: "terrain"
    });

    var marker = new google.maps.Marker({
        position: markerLatLng,
        map: map, // handle of the map
        draggable:true
    });
    map.addListener('click',function(event){
        console.log(event.latLng.lat());
        markerLatLng = event.latLng;
        if(typeof (marker) === 'object'){
            marker.setMap(null);
        }
        marker = new google.maps.Marker({
            position: markerLatLng,
            map: map, // handle of the map
            draggable:true
        });
        document.getElementById('lat').value = event.latLng.lat();
        document.getElementById('lng').value = event.latLng.lng();
    });

    // if(typeof (marker) === 'object') {
    marker.addListener('drag',function (event) {
            console.log(event,marker);
            document.getElementById('lat').value = event.latLng.lat();
            document.getElementById('lng').value = event.latLng.lng();
    });
    // }
}
</script>

<?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/drones/form.blade.php ENDPATH**/ ?>