


<?php $__env->startSection('title'); ?>
    <title>end point || all</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_head'); ?>
    <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1>end points || <small> ALL </small></h1>
        </div>
        <!-- END PAGE TITLE -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('rapper'); ?>


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="<?php echo e(route('end_points.index')); ?>">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="#">end points</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet box grey-cascade">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-globe"></i>All end points
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload">
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-6">
                                <div class="btn-group pull-right">
                                    <a href="<?php echo e(route('end_points.create')); ?>" id="sample_editable_1_new" class="btn green">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover" id="sample_1">
                        <thead>
                        <tr>
                            <th>
                                name
                            </th>
                            <th>
                                map
                            </th>
                            <th>
                                update
                            </th>
                            <th>
                                delete
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $end_points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end_point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td>
                                    <?php echo e($end_point->name); ?>

                                </td>
                                <td>
                                    <?php echo $end_point->starting_point; ?>

                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('end_points.edit',$end_point->id)); ?>" id="sample_editable_1_new" class="btn green">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <?php echo $end_point->delete_button; ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
    <input type="hidden" id="new_path_id" value="0">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&libraries=&v=weekly"
            defer
    ></script>
    <script src="<?php echo e(asset('sweetalert/sweetalert2.all.min.js')); ?>"></script>
    <!-- page script -->
    <script>
        function deleteItem(obj,end_point_id){
            // console.log(obj.parentElement.parentElement);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    var fd = new FormData();
                    fd.append( '_token','<?php echo e(csrf_token()); ?>');
                    fd.append( '_method','DELETE');

                    $.ajax({
                        url: end_point_id,
                        data: fd,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        success: function(data){
                            console.log(data);
                            if(!data.errors){
                                obj.parentElement.parentElement.parentElement.parentElement.removeChild(obj.parentElement.parentElement.parentElement);
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    data.msg,
                                    'success'
                                )
                            }else{
                                swalWithBootstrapButtons.fire(
                                    'Error!',
                                    data.msg,
                                    'danger'
                                )
                            }
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        }
        function ShowStartingPoint(lat,lng){
            // document.getElementById("modal_body").value = '';
            var markerLatLng = new google.maps.LatLng(lat,lng);

            var map = new google.maps.Map(document.getElementById("modal_body"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });

            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });
        }
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/end_points/end_points.blade.php ENDPATH**/ ?>