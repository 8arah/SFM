


<?php $__env->startSection('title'); ?>
    <title>wisdom || all</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('rapper'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>wisdoms</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('wisdoms.index')); ?>" style="text-decoration: none;">wisdoms</a></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>


    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('/control_panel/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/control_panel/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sweetalert/sweetalert2.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">wisdom</h3>
            <div class="card-tools">
                <a class="btn btn-primary" href="<?php echo e(route('wisdoms.create')); ?>">
                    <i class="fas fa-plus"></i>
                </a>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Body</th>
                        <th>Author</th>
                        <th>Source</th>
                        <th>Created at</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $wisdoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisdom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($wisdom->body); ?></td>
                            <td><?php echo e($wisdom->author); ?></td>
                            <td><?php echo e($wisdom->source); ?></td>
                            <td><?php echo e($wisdom->create_at); ?></td>
                            <td>
                                <a class="btn btn-warning" href="<?php echo e(route('wisdoms.edit',$wisdom->id)); ?>">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a class="btn btn-danger" href="#!" onclick="deleteItem(this,'<?php echo e($wisdom->id); ?>')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Body</th>
                        <th>Author</th>
                        <th>Source</th>
                        <th>Created at</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <!-- DataTables -->
    <script src="<?php echo e(asset('/control_panel/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/control_panel/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/control_panel/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/control_panel/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>
    <script src="<?php echo e(asset('sweetalert/sweetalert2.all.min.js')); ?>"></script>
    <!-- page script -->
    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
        });
        function deleteItem(obj,wisdom_id){
            // console.log(obj.parentElement.parentElement);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    var fd = new FormData();
                    fd.append( '_token','<?php echo e(csrf_token()); ?>');
                    fd.append( '_method','DELETE');

                    $.ajax({
                        url: "/wisdoms/"+wisdom_id,
                        data: fd,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        success: function(data){
                            if(!data.errors){
                                obj.parentElement.parentElement.parentElement.removeChild(obj.parentElement.parentElement);
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    data.msg,
                                    'success'
                                )
                            }else{
                                swalWithBootstrapButtons.fire(
                                    'Error!',
                                    data.msg,
                                    'danger'
                                )
                            }
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\wisdom\resources\views/control_panel/wisdoms/end_points.blade.php ENDPATH**/ ?>