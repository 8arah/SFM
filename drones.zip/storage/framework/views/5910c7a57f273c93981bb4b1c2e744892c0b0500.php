    <div class="alert alert-<?php echo e(session('status')); ?> alert-dismissible fade show" role="alert">
        <strong>Wisdom || </strong> <?php echo e(session('msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php /**PATH C:\xampp\htdocs\projects\wisdom\resources\views/control_panel/alert.blade.php ENDPATH**/ ?>