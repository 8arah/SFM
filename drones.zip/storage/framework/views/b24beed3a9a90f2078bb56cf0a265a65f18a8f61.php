<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->yieldContent('title'); ?>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/control_panel/plugins/fontawesome-free/css/all.min.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/control_panel/dist/css/adminlte.min.css')); ?>">

</head>
<body class="hold-transition sidebar-mini">
<?php if(\Illuminate\Support\Facades\Auth::guest()): ?>

<?php elseif(\Illuminate\Support\Facades\Auth::user()->role < 2): ?>
<!-- Site wrapper -->
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        
            
                
            
            
                
            
            
                
            
        

        <!-- SEARCH FORM -->
        
            
                
                
                    
                        
                    
                
            
        

        <!-- Right navbar links -->
        
            
            
                
                    
                    
                
                
                    
                        
                        
                            
                            
                                
                                    
                                    
                                
                                
                                
                            
                        
                        
                    
                    
                    
                        
                        
                            
                            
                                
                                    
                                    
                                
                                
                                
                            
                        
                        
                    
                    
                    
                        
                        
                            
                            
                                
                                    
                                    
                                
                                
                                
                            
                        
                        
                    
                    
                    
                
            
            
            
                
                    
                    
                
                
                    
                    
                    
                        
                        
                    
                    
                    
                        
                        
                    
                    
                    
                        
                        
                    
                    
                    
                
            
            
                
                    
                
            
        
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="../../index3.html" class="brand-link">
            <img src="<?php echo e(asset('/control_panel/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
            <span class="brand-text font-weight-light">Wisdom</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>
                                <?php echo e(Auth::user()->name); ?>

                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="fa fa-person-booth nav-icon"></i>

                                    <p><?php echo e(__('Logout')); ?></p>
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>

            <!-- SidebarSearch Form -->
            
                
                    
                    
                        
                            
                        
                    
                
            

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <li class="nav-item">
                        <a href="<?php echo e(route('wisdoms.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-th"></i>
                            <p>
                                Wisdoms
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <?php echo $__env->yieldContent('rapper'); ?>

        <!-- Main content -->
        <section class="content">
            <?php if(session('msg')): ?>
                <?php echo $__env->make('control_panel.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer">
        
            
        
        
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php endif; ?>

<!-- jQuery -->
<script src="<?php echo e(asset('/control_panel/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('/control_panel/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('/control_panel/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('/control_panel/dist/js/demo.js')); ?>"></script>

<?php echo $__env->yieldContent('extra_script'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\wisdom\resources\views/control_panel/master2.blade.php ENDPATH**/ ?>