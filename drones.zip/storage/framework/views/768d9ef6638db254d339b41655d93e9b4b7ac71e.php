<?php echo csrf_field(); ?>
<div class="card-body">
    <div class="form-group">
        <label for="body">Body</label>
        <textarea name="body" class="form-control <?php if($errors->first('body')): ?> is-invalid <?php endif; ?>" id="body" placeholder="Enter Body"><?php echo e(old('body',$wisdom->body)); ?></textarea>
        <?php if($errors->first('body')): ?>
            <span id="body-error" class="error invalid-feedback"><?php echo e($errors->first('body')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="author">Author</label>
        <input type="text" name="author" class="form-control <?php if($errors->first('author')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('author',$wisdom->author)); ?>" id="author" placeholder="Enter author">
        <?php if($errors->first('author')): ?>
            <span id="body-error" class="error invalid-feedback"><?php echo e($errors->first('author')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="source">Source</label>
        <input type="text" name="source" class="form-control <?php if($errors->first('source')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('source',$wisdom->source)); ?>" id="source" placeholder="Enter source">
        <?php if($errors->first('source')): ?>
            <span id="body-error" class="error invalid-feedback"><?php echo e($errors->first('source')); ?></span>
        <?php endif; ?>
    </div>
</div>

<input type="hidden" name="id" value="<?php echo e($wisdom->id); ?>"><?php /**PATH C:\xampp\htdocs\projects\wisdom\resources\views/control_panel/wisdoms/form.blade.php ENDPATH**/ ?>