<?php echo csrf_field(); ?>
<div class="form-body">
    <div class="form-group <?php if($errors->first('details')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">Details</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <?php if($errors->first('details')): ?>
                    <i class="fa fa-warning tooltips" data-original-title="<?php echo e($errors->first('details')); ?>"></i>
                <?php endif; ?>
                <textarea name="details" rows="7" class="form-control" placeholder="Enter your order details"/><?php echo e(old('details',$path->details)); ?></textarea>
                <?php if($errors->first('details')): ?>
                    <span id="name-error" class="help-block help-block-error"><?php echo e($errors->first('details')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="form-body">
    <div class="form-group <?php if($errors->first('lat')||$errors->first('lng')): ?> has-error <?php endif; ?>">
        <label class="control-label col-md-3">Enter your distination</label>
        <div class="col-md-8">
            <div class="input-icon right">
                <div class="portlet-body">
                    <div id="map" class="gmaps">
                    </div>
                    <?php if($errors->first('lat')||$errors->first('lng')): ?>
                        <span id="name-error" class="help-block help-block-error">Please select a valid starting point</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="id" value="<?php echo e($path->id); ?>">
<input type="hidden" name="lat" id="lat" value="<?php echo e($path->latitude); ?>">
<input type="hidden" name="lng" id="lng" value="<?php echo e($path->longitude); ?>">


<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&callback=initMap&libraries=&v=weekly"
        defer
></script>
<script>
function initMap() {
    var markerLatLng = new google.maps.LatLng('<?php echo e($path->latitude); ?>','<?php echo e($path->longitude); ?>');

    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16,
        center: markerLatLng,
        mapTypeId: "terrain"
    });

    var marker = new google.maps.Marker({
        position: markerLatLng,
        map: map, // handle of the map
        draggable:true
    });
    map.addListener('click',function(event){
        console.log(event.latLng.lat());
        markerLatLng = event.latLng;
        if(typeof (marker) === 'object'){
            marker.setMap(null);
        }
        marker = new google.maps.Marker({
            position: markerLatLng,
            map: map, // handle of the map
            draggable:true
        });
        document.getElementById('lat').value = event.latLng.lat();
        document.getElementById('lng').value = event.latLng.lng();
    });

    // if(typeof (marker) === 'object') {
    marker.addListener('drag',function (event) {
            console.log(event,marker);
            document.getElementById('lat').value = event.latLng.lat();
            document.getElementById('lng').value = event.latLng.lng();
    });
    // }
}
</script>

<?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/orders/form.blade.php ENDPATH**/ ?>