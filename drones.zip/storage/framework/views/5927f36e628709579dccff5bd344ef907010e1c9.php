<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Drone Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    <meta name="author" content="..." />

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />

    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/bootstrap.css')); ?>">
    <!-- Owl Carousel  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/owl.theme.default.min.css')); ?>">
    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/animate.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/all.css')); ?>">
    <!-- Font Google -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
    <!-- Theme style  -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/style.css')); ?>">

    <!-- Theme Editor-->
    <!--<link rel="stylesheet" href="css/blackash.css">-->

</head>
<body>


<div id="page-wrap">


    <!-- ====================================================== Header ================================================= -->

    <div id="na-header-wrapper">

        <div class="site-header header-fixed navbar navbar-expand-lg main-navbar-nav navbar-light">
            <div class="container">
                <a id="logo" class="logo" href="#">
                    <img class="logo-img"  src="<?php echo e(asset('control_panel/logo.png')); ?>" alt="logo" style="max-width: 50px">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="icon-toggler"></i>
                    <i class="icon-toggler"></i>
                    <i class="icon-toggler"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav nav-items-center ml-auto mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="/" >Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#na-introduce">Introduction</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#na-guide">Our Works</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#na-review">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#na-form">Contact Us</a>
                        </li>
                    </ul>
                    <div class="btn-header">
                        <a class="btn-link" href="<?php echo e(route('login')); ?>">Login</a>
                        <a class="btn-link" href="<?php echo e(route('register')); ?>">Register</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-header-hoder"></div>
        <br><br>

        <section>
            <div class="container h-100">
                <div class="row justify-content-md-center h-100">
                    <div class="card-wrapper">
                        <div class="card fat">
                            <div class="card-body">
                                <h4 class="card-title">Login</h4>
                                <form method="POST" action="<?php echo e(route('login')); ?>" class="my-login-validation" novalidate="">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="email">E-Mail Address</label>
                                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="password">Password &nbsp;
                                            
                                                
                                            
                                        </label>
                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required data-eye>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    
                                        
                                            
                                            
                                        
                                    

                                    <div class="form-group m-0">
                                        <button type="submit" class="btn btn-primary btn-block">
                                            Login
                                        </button>
                                    </div>
                                    
                                        
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </div>



</div> <!-- main page wrapper -->

<script src="<?php echo e(asset('landing/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('landing/js/main.js')); ?>"></script>

<!-- Theme Editor-->
<!--<script src="js/blackash-editor.js"></script>-->
<!--<script src="js/getcolor.js"></script>-->

<input style="top: 340px; opacity: 0; border: 5px solid white; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px inset, rgba(0, 0, 0, 0.1) 0px 0px 16px; padding: 15px; background: rgb(255, 41, 184) none repeat scroll 0% 0%; margin: 0px 0px 10px; position: fixed; left: 20px; color: rgb(255, 255, 255); height: 40px; z-index: 9999;"
       class="jscolor colorpcikewebjs" value="FF29B8" autocomplete="off">
</body>
</html><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/auth/login.blade.php ENDPATH**/ ?>