


<?php $__env->startSection('title'); ?>
    <title>drone || all</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title_head'); ?>
    <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1>Drones || <small> ALL </small></h1>
        </div>
        <!-- END PAGE TITLE -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('rapper'); ?>


    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="<?php echo e(route('drones.index')); ?>">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="#">Drones</a>
            <i class="fa fa-circle"></i>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet box grey-cascade">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-globe"></i>All Drones
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="javascript:;" class="reload">
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="table-toolbar">
                        <div class="row">
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-6">
                                <div class="btn-group pull-right">
                                    <a href="<?php echo e(route('drones.create')); ?>" id="sample_editable_1_new" class="btn green">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered table-hover" id="sample_1">
                        <thead>
                        <tr>
                            <th class="table-checkbox">
                                IP
                            </th>
                            <th>
                                stationary point
                            </th>
                            <th>
                                orders
                            </th>
                            <th>
                                buttery
                            </th>
                            <th>
                                weight
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Actions
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $drones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td>
                                    <?php echo e($drone->mac); ?>

                                </td>
                                <td>
                                    <?php echo $drone->starting_point; ?>

                                </td>
                                <td>
                                    <?php echo $drone->orders; ?>

                                </td>
                                <td>
                                    <?php echo e($drone->buttery); ?>

                                </td>
                                <td>
                                    <?php echo e($drone->weight); ?>

                                </td>
                                <td class="center">
                                    <a><?php echo $drone->status; ?></a>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('drones.edit',$drone->id)); ?>" id="sample_editable_1_new" class="btn green">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </div>
                                    <div class="btn-group">
                                        <a href="#!" id="sample_editable_1_new" class="btn red" onclick="deleteItem(this,'<?php echo e($drone->id); ?>')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
    <input type="hidden" id="new_path_id" value="0">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAz_8_8EQUhBhlnmO9ZxM35iLHBwr72PSc&libraries=&v=weekly"
            defer
    ></script>
    <script src="<?php echo e(asset('sweetalert/sweetalert2.all.min.js')); ?>"></script>
    <!-- page script -->
    <script>
        function deleteItem(obj,drone_id){
            // console.log(obj.parentElement.parentElement);
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    var fd = new FormData();
                    fd.append( '_token','<?php echo e(csrf_token()); ?>');
                    fd.append( '_method','DELETE');

                    $.ajax({
                        url: "/drones/"+drone_id,
                        data: fd,
                        processData: false,
                        contentType: false,
                        type: 'POST',
                        success: function(data){
                            if(!data.errors){
                                obj.parentElement.parentElement.parentElement.parentElement.removeChild(obj.parentElement.parentElement.parentElement);
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    data.msg,
                                    'success'
                                )
                            }else{
                                swalWithBootstrapButtons.fire(
                                    'Error!',
                                    data.msg,
                                    'danger'
                                )
                            }
                        }
                    });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your imaginary file is safe :)',
                        'error'
                    )
                }
            })
        }
        function NewOrder(lat,lng,drone_id,last_path_id,end_point_lat,end_point_lng){
            if(last_path_id){
                document.getElementById('new_path_id').value = last_path_id;
            }
            console.log({lat: parseFloat(end_point_lat), lng: parseFloat(end_point_lng)});
            var markerLatLng = new google.maps.LatLng(lat,lng);

            var map = new google.maps.Map(document.getElementById("modal_body"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });

            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });

            var end_point_marker = new google.maps.Marker({
                position: {lat: parseFloat(end_point_lat), lng: parseFloat(end_point_lng)},
                map: map
            });
            var new_path_id = document.getElementById('new_path_id').value;
            map.addListener('click',function(event){
                console.log(event.latLng.lat());
                // markerLatLng = event.latLng;
                // if(typeof (end_point_marker) === 'object'){
                    end_point_marker.setMap(null);
                // }
                end_point_marker = new google.maps.Marker({
                    position: {lat:event.latLng.lat(),lng:event.latLng.lng()},
                    map: map
                });
                console.log('/addNewPath/'+drone_id+'/'+new_path_id+'/'+lat+'/'+lng);
                $.get('/addNewPath/'+drone_id+'/'+new_path_id+'/'+event.latLng.lat()+'/'+event.latLng.lng(),function(data){
                    document.getElementById('new_path_id').value = data.id
                    // console.log(data);
                });
            });
        }
        function ShowStartingPoint(lat,lng){
            // document.getElementById("modal_body").value = '';
            var markerLatLng = new google.maps.LatLng(lat,lng);

            var map = new google.maps.Map(document.getElementById("modal_body"), {
                zoom: 16,
                center: markerLatLng,
                mapTypeId: "terrain"
            });

            var marker = new google.maps.Marker({
                position: markerLatLng,
                map: map
            });
        }

    </script>
    <script>
        // jQuery(document).ready(function() {
        //     Metronic.init(); // init metronic core components
        //     Layout.init(); // init current layout
        //     Demo.init(); // init demo features
        //     TableManaged.init();
        // });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\drones\resources\views/control_panel/drones/drones.blade.php ENDPATH**/ ?>