


<?php $__env->startSection('title'); ?>
    <title>wisdom || Create New Wisdom</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('rapper'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>wisdoms</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('wisdoms.index')); ?>" style="text-decoration: none;">wisdoms</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('wisdoms.update',$wisdom->id)); ?>" style="text-decoration: none;">update</a></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Wisdom <small>update</small></h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form id="quickForm" method="post" action="<?php echo e(route('wisdoms.update',$wisdom->id)); ?>">
            <input type="hidden" name="_method" value="PUT">
            <?php echo $__env->make('control_panel.wisdoms.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /.card-body -->
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <!-- jquery-validation -->
    <script src="<?php echo e(asset('/control_panel/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/control_panel/plugins/jquery-validation/additional-methods.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>


    <script>
        $(function () {
            $('#quickForm').validate({
                rules: {
                    body: {
                        required: true,
                        minlength: 10
                    }
                },
                messages: {
                    body: {
                        required: "Please enter a valid wisdom",
                        minlength: "the minimum length is 10 characters"
                    }
                },
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('control_panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\wisdom\resources\views/control_panel/wisdoms/update.blade.php ENDPATH**/ ?>