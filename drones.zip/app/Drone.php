<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Drone extends Model
{
    protected $fillable = ['mac','heat','start_end_point_id','user_id','buttery','weight'];
    public function getCreateAtAttribute(){
        return $this->created_at ? $this->created_at->diffForHumans() : 0 ;
    }
    public function location(){ //station
        return $this->belongsTo(StartEndPoint::class,'start_end_point_id','id') ;
    }
    public function getStationNameAttribute(){
        return $this->location ? $this->location->name : '';
    }
    public function paths(){
        return $this->hasMany(Path::class);
    }
    public function inProgressPath(){
        return $this->hasMany(Path::class)->where('status',1);
    }
    public function locations(){
        return $this->hasManyThrough(Location::class,Path::class);
    }
    public function getStatusAttribute(){
        $busy_path = $this->paths()->where('status',1)->first();
        return $busy_path ? $busy_path->status
            ? '<span class="label label-sm label-danger">busy </span>'
            : '<span class="label label-sm label-success">available</span>'
            : '<span class="label label-sm label-success">available</span>';
    }
    public function getStatusAsBooleanAttribute(){
        $busy_path = $this->inProgressPath()->first();
//        dd($busy_path);
        return $busy_path ? $busy_path->status
            ? 1
            : 0
            : 0;
    }
    public function getStartingPointAttribute(){
        return '<a class="btn default" data-toggle="modal" href="#large" onclick="ShowStartingPoint(\''.$this->latitude.'\',\''.$this->longitude.'\')">view stationary point</a>';
    }
    public function getNewOrderAttribute(){
        $last_path = $this->paths->last();
//        return $last_path;
        if(!$last_path || $last_path->status) {
            return '<a class="btn default" data-toggle="modal" href="#large" onclick="NewOrder(\'' . $this->latitude . '\',\'' . $this->longitude . '\',\'' . $this->id . '\',0,0,0)">New Order</a>';
        }else{
            $location = $last_path->locations->last();
            return '<a class="btn default" data-toggle="modal" href="#large" onclick="NewOrder(\'' . $this->latitude . '\',\'' . $this->longitude . '\',\'' . $this->id . '\',\''.$last_path->id.'\',\''. $location->latitude .'\',\''.$location->longitude.'\')">New Order</a>';
        }
    }
    public function getOrdersAttribute(){
        return '<a href="'.route('drones.show',$this->id).'" class="btn btn-info">orders</a>';
    }
    public function getLatitudeAttribute(){
        return $this->location ? $this->location->lat : '21.543333';
    }
    public function getLongitudeAttribute(){
        return $this->location ? $this->location->lng : '39.172779';
    }
}
