<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    protected $fillable = ['path_id','lat','lng'];
    protected $appends = ['longitude','latitude'];
    public function getLatitudeAttribute(){
        return $this->lat ? $this->lat : '21.543333';
    }
    public function getLongitudeAttribute(){
        return $this->lng ? $this->lng : '39.172779';
    }
    public function getLocationObjectAttribute(){
        return '{lat : '.$this->latitude.',lng : '.$this->longitude.'}';
    }
}
