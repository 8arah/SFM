<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Path extends Model
{
    use SoftDeletes;
    protected $fillable = ['drone_id','status','working_trigger','details','lat','lng','station_name','user_id','deleted_at']; //Lat and Lng is the client order point
    public function locations(){
        return $this->hasMany(Location::class);
    }
    public function drone(){
        return $this->belongsTo(Drone::class,'drone_id','id');
    }
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function getDroneNameAttribute(){
        return $this->drone ? $this->drone->mac : 'still pending order';
    }
    public function getCreateAtAttribute(){
        return $this->created_at ? $this->created_at->diffForHumans() : 0 ;
    }
    public function getLatitudeAttribute(){
        return $this->lat ? $this->lat : '21.543333';
    }
    public function getLongitudeAttribute(){
        return $this->lat ? $this->lng : '39.172779';
    }

    public function getDistinationPointAttribute(){
        return '<a class="btn default" data-toggle="modal" href="#large" onclick="ShowDistinationPoint(\''.$this->latitude.'\',\''.$this->longitude.'\',\''.$this->id.'\')">view destination point</a>';
    }

    public function getStatusValueAttribute(){
        switch ($this->status){
            case 1: {return '<span class="label label-sm label-danger">in progress </span>';}break;
            case 2: {return '<span class="label label-sm label-info">done </span>';}break;
            case 3: {return '<span class="label label-sm label-warning">stopped </span>';}break;
            case 0: {return '<span class="label label-sm label-success">waiting </span>';}break;
        }
    }
    public function getUserNameAttribute(){
        return $this->user ? $this->user->name : '';
    }
}
