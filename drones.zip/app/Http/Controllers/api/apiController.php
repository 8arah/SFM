<?php

namespace App\Http\Controllers\api;

use App\Drone;
use App\Http\Controllers\Controller;
use App\Location;
use App\Path;
use App\StartEndPoint;
use Illuminate\Http\Request;

class apiController extends Controller
{

    public function getAllPoints(){
        $points = StartEndPoint::where('status',1)->withCount('drone')->get();
//            ->groupBy(function ($item, $key) {
//            if($item->status){
////                return 'start';
//            }else{
//                return 'stations';
//            }
//        });
        return $points;
    }
    public function getAllAvailableDrones(){
        $drones = Drone::all()->filter(function($item){
            if(!$item->status_as_boolean){
                return $item->append('station_name');
            }
        });
//            ->each(function($item){
//            $item->append('status_as_boolean');
//        });
//            ->groupBy(function ($item, $key) {
//            if($item->status){
////                return 'start';
//            }else{
//                return 'stations';
//            }
//        });
        return $drones;
    }
    public function getWaitingOrders(){
        $orders = Path::where('status',0)->get();
        return $orders;
    }
    public function getOnProcessingOrders(){
        $orders = Path::where('status',1)->get();
        return $orders;
    }
    public function getDoneOrders(){
        $orders = Path::where('status',2)->get();
        return $orders;
    }
    public function setOrderToBeDone($path_id,$station_id){
        $order = Path::where('status',1)->find($path_id);
//        return $order;
        if($order){
            $order->update(['status'=>2]);
            if($order->drone){
                if((int)$station_id) {
                    $order->drone->update(['start_end_point_id' => $station_id]);
                }else{
                    return response()->json(['msg' => 'station id is wrong', 'errors' => 1]);
                }
            }else{
                return response()->json(['msg' => 'drone data not found', 'errors' => 1]);
            }
        }else{
            return response()->json(['msg' => 'order not found or it is not in progress', 'errors' => 1]);
        }
        return response()->json(['msg' => 'done', 'errors' => 0]);
    }
    public function getAvailableDrones(){
        $drones = Drone::whereDoesntHave('paths',function($query){
            $query->where('drone_id',null)->orWhere('status',0);
        })->get();
        return $drones;
    }
    public function setPathForOrder(Request $request,$path_id,$drone_id){
        $order = Path::find($path_id);
        $drone = Drone::whereDoesntHave(
            'paths',function($query) use($drone_id){
                $query->where('status',1);
            })
            ->where('id',$drone_id)->first();
        if($drone) {
            if ($order) {
                if (!$order->status) {
                    $order->update(['status' => 1,'drone_id' => $drone_id]);
                    foreach ($request->toArray() as $key => $item) {
                        Location::create([
                            "path_id" => $path_id,
                            "lat" => $item['lat'],
                            "lng" => $item['lng']
                        ]);
                    }
                    return response()->json(['msg' => 'done', 'errors' => 0]);
                } else {
                    return response()->json(['msg' => 'you can\'t update the path', 'path' => $order->load('locations'), 'errors' => 1]);
                }
            } else {
                return response()->json(['msg' => 'there is no data for the order id which you sent.', 'errors' => 1]);
            }
        }else{
            return response()->json(['msg' => 'the drone is busy now', 'errors' => 1]);
        }
    }
    public function getDroneOrderStatus($drone_id){
        $drone = Drone::with(['paths'=>function($query){
            $query->where('status',1)->first();
        }])->whereHas('inProgressPath')->find($drone_id);
//        return $drone;
        if($drone){
            if($drone->paths->count()){
                if($drone->paths[0]->working_trigger){
                    $drone->paths[0]->update(['status'=>3]);
                }
                return response()->json(['trigger'=>$drone->paths[0]->working_trigger,'errors'=>0]);
            }
        }else{
            return response()->json(['msg' => 'the drone have no in progress orders', 'errors' => 1]);
        }
    }
}
