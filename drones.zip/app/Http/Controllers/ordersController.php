<?php

namespace App\Http\Controllers;

use App\Http\Requests\newOrderRequest;
use App\Http\Requests\updateOrderRequest;
use App\Location;
use App\Path;
use App\StartEndPoint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PhpParser\ParserAbstract;

class ordersController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->role) {
            $orders = Path::where('user_id', Auth::id())->get();
            return view('control_panel.orders.orders', compact('orders'));
        }else{
            $orders = Path::all();
            return view('control_panel.orders.orders', compact('orders'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $path = new Path();
        $station_points = StartEndPoint::where('status',1)->get()
            ->filter(function($item){
                if(!$item->drone){
                    $item->path_count = 0;
                    return $item;
                }
            });
        $default_lat = $path->latitude;
        $default_lng = $path->longitude;
        $default_station_name = '';
        if($station_points->count()){
            if($station_points[0]){
                if($station_points[0]->lat){
                    $default_lat = $station_points[0]->lat;
                }
                if($station_points[0]->lng){
                    $default_lng = $station_points[0]->lng;
                }
                if($station_points[0]->name){
                    $default_station_name = $station_points[0]->name;
                }
            }
        }
        return view('control_panel.orders.create',compact('path','station_points','default_station_name','default_lat','default_lng'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(newOrderRequest $request)
    {
        Path::create(array_merge($request->all(),['user_id'=>Auth::id()]));
        return redirect()->back()->with(['msg'=>'a new order is inserted successfully into the DataBase','status'=>'success']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $path = Path::findOrFail($id);
        $station_points = StartEndPoint::where('status',1)
            ->get()
            ->filter(function($item) use ($path){
                if($item->drone){
                    if($item->lat == $path->lat&&$item->lng == $path->lng){
                        $item->path_count = 1;
                        return $item;
                    }
                }else{
                    $item->path_count = 0;
                    return $item;
                }
            });
        $default_lat = $path->latitude;
        $default_lng = $path->longitude;
        $default_station_name = '';
        if($station_points->count()){
            if($station_points[0]){
                if($station_points[0]->lat){
                    $default_lat = $station_points[0]->lat;
                }
                if($station_points[0]->lng){
                    $default_lng = $station_points[0]->lng;
                }
                if($station_points[0]->name){
                    $default_station_name = $path->station_name;
                }
            }
        }
        return view('control_panel.orders.update', compact('path','station_points','default_station_name','default_lng','default_lat'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(updateOrderRequest $request, $id)
    {
        $path = Path::findOrFail($id);
        if(!$path->status) {
            $path->update($request->all());
            return redirect()->back()->with(['msg' => 'order data is updated successfully', 'status' => 'success']);
        }else{
            return redirect()->back()->with(['msg' => 'order is started and can\'t be updated', 'status' => 'danger']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = Path::find($id);
        if($order){
            if($order->status){
                return response()->json(['msg'=>'the order is started,you can\'t delete it','errors'=>1]);
            }else {
                $order->delete();
                return response()->json(['msg' => 'the order is deleted successfully', 'errors' => 0]);
            }
        }else{
            return response()->json(['msg'=>'no order found in DB for your entry','errors'=>1]);
        }
    }
    public function getOrderPath($path_id){
        $points = Location::where('path_id',$path_id)->get();
        return $points;
    }
    public function stop($path_id){
        $path = Path::find($path_id);
        if($path){
            $path->update(['working_trigger'=>1]);
//            $drone = $path->drone;
//            if($drone){
//                $drone->update(['']);
//            }
            return redirect()->back()->with(['msg' => 'the order is stoped successfully','status'=>'danger']);
        }else{
            return redirect()->back()->with(['msg'=>'no order found in DB for your entry','status'=>'danger']);
        }
    }
    public function history(){
        if(!Auth::user()->role){
            $orders = Path::withTrashed()->get();
        }else{
            $orders = Path::withTrashed()->where('user_id',Auth::id())->get();
        }
        return view('control_panel.orders.history', compact('orders'));
    }
}
