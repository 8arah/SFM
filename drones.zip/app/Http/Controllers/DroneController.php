<?php

namespace App\Http\Controllers;

use App\Drone;
use App\Http\Requests\newDroneRequest;
use App\Http\Requests\updateDroneRequest;
use App\Http\Resources\getDronePaths;
use App\Path;
use App\StartEndPoint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DroneController extends Controller
{

    public $locations = array();
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($trigger=0)
    {
        $drones = Drone::withCount('paths')->get()->filter(function ($item) use($trigger) {
            if($item->status == $trigger){
                return $item;
            }
        });
        return view('control_panel.drones.drones',compact('drones'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $drone = new Drone();
        $start_points = StartEndPoint::where('status',1)->whereDoesntHave(
            'drone',function($query) use($drone){
            $query->where('id','!=',$drone->start_end_point_id);
        }
        )->withCount(['drone'=>function($query) use($drone){
            $query->where('id',$drone->start_end_point_id);
        }])->get();
        return view('control_panel.drones.create',compact('drone','start_points'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(newDroneRequest $request)
    {
//        dd($request);
        $drone = Drone::create(array_merge($request->all(),['user_id'=>Auth::id()]));
        return redirect()->back()->with(['msg'=>'a new drone is inserted successfully into the DataBase','status'=>'success']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $drone
     * @return \Illuminate\Http\Response
     */
    public function show($drone)
    {
        if($drone) {
            return view('control_panel.drones.show', compact('drone'));
        }else{
            return redirect()->back()->with(['msg'=>'invalid request || no data found for your request','status'=>'danger']);
        }
    }
    public function dronePaths($drone){
        if ($drone){
            $drone->load(['paths'=>function($query){
                $query->where('status',1);
            },'paths.locations']);
            $drone->paths->each(function($path,$key){
                return $this->locations[$key] = $path->locations->toArray();
            });
            return $this->locations;
        }else{

        }
    }
    public function addNewPath($drone,$path,$lat,$lng){
//        dd(12);
//        dd($path,$lat,$lng);
        if(!$path){
            $path = Path::create(['drone_id'=>$drone->id]);
            $path->locations()->create(['lat'=>$drone->latitude,'lng'=>$drone->longitude]);
            $path->locations()->create(['lat'=>$lat,'lng'=>$lng]);
            return $path;
        }else{
            $path->locations[1]->update(['lat'=>$lat,'lng'=>$lng]);
            return $path;
        }
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $drone
     * @return \Illuminate\Http\Response
     */
    public function edit($drone)
    {
        if($drone) {
            $start_points = StartEndPoint::where('status',1)
//                ->withCount(['drone'=>function($query) use($drone){
//                    $query->where('id','=',$drone->start_end_point_id);
//                }])
            ->get()->filter(function($item) use ($drone){
                    if($item->drone){
                        if($item->id == $drone->start_end_point_id){
                            $item->drone_count = 1;
                            return $item;
                        }
                    }else{
                        $item->drone_count = 0;
                        return $item;
                    }
                });
//            dd($drone->start_end_point_id,$start_points);
            return view('control_panel.drones.update', compact('drone','start_points'));
        }else{
            return redirect()->back()->with(['msg'=>'invalid request || no data found for your request','status'=>'danger']);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $drone
     * @return \Illuminate\Http\Response
     */
    public function update(updateDroneRequest $request, $drone)
    {
        if($drone) {
            $drone->update(array_merge($request->all(),['user_id'=>Auth::id()]));
            return redirect()->back()->with(['msg' => 'drone data is updated successfully', 'status' => 'success']);
        }else{
            return redirect()->back()->with(['msg'=>'invalid request || no data found for your request','status'=>'danger']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $drone
     * @return \Illuminate\Http\Response
     */
    public function destroy($drone)
    {
        if($drone){
            if($drone->paths->count()){
                return response()->json(['msg'=>'you have to delete drone paths before you can delete it','errors'=>1]);
            }else {
                $drone->delete();
                return response()->json(['msg' => 'the Drone is deleted successfully', 'errors' => 0]);
            }
        }else{
            return response()->json(['msg'=>'no drone found in DB for your entry','errors'=>1]);
        }
    }
    public function liveMap(){
        Drone::whereHas('inProgressPath')->get()->each(function ($item) {
            $item->inProgressPath->each(function ($path, $key) {
//                dd($path->locations);
                return $this->locations[$key] = $path->locations->toArray();
            });
        });
        return $this->locations;
    }
    public function dronesLiveMapView(){
        Drone::whereHas('inProgressPath')->get()->each(function ($item) {
            $item->inProgressPath->each(function ($path, $key) {
//                dd($path->locations);
                return $this->locations[$key] = $path->locations->toArray();
            });
        });
        if(count($this->locations)) {
            $lat = $this->locations[0][0]['latitude'];
            $lng = $this->locations[0][0]['longitude'];
            $noOrdersTrigger = 0;
        }else{
            $lat = '21.543333';
            $lng = '39.172779';
            $noOrdersTrigger = 1;
        }
//        dd($this->locations);
        return view('control_panel.drones.liveMap',compact('drones','lat','lng','noOrdersTrigger'));
    }
}
