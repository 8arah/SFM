<?php

namespace App\Http\Controllers;

use App\Http\Requests\newEndPointRequest;
use App\Http\Requests\updateEndPointRequest;
use App\StartEndPoint;
use Illuminate\Http\Request;

class endPointController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $end_points = StartEndPoint::where('status',1)->get();
        return view('control_panel.end_points.end_points',compact('end_points'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $end_point = new StartEndPoint();
        return view('control_panel.end_points.create',compact('end_point'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(newEndPointRequest $request)
    {
        $end_point = StartEndPoint::create(array_merge($request->all(),['status'=>1]));
        return redirect()->back()->with(['msg'=>'a new ending point is inserted successfully into the DataBase','status'=>'success']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $end_point = StartEndPoint::findOrFail($id);
        return view('control_panel.end_points.update', compact('end_point'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(updateEndPointRequest $request, $id)
    {
        $end_point = StartEndPoint::findOrFail($id);
        $end_point->update($request->all());
        return redirect()->back()->with(['msg' => 'end point data is updated successfully', 'status' => 'success']);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $end_point = StartEndPoint::find($id);
//        return $end_point->drone;
        if($end_point){
            if($end_point->drone){
                return response()->json(['msg'=>'there are a drone in this ending point,you can\'t delete it','errors'=>1]);
            }else {
                $end_point->delete();
                return response()->json(['msg' => 'the end point is deleted successfully', 'errors' => 0]);
            }
        }else{
            return response()->json(['msg'=>'no end point found in DB for your entry','errors'=>1]);
        }
    }
}
