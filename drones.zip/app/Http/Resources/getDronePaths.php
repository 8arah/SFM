<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class getDronePaths extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public $path;
    public function __construct($path)
    {
        $this->path = $path;
    }

    public function toArray($request)
    {
        $locations = '';
        foreach ($this->path->locations as $location){
            if(strlen($locations)) {
                $locations = $locations . ',{lat:' . $location->latitude . ',lng:' . $location->longitude . '}';
            }else{
                $locations = $locations . '{lat:' . $location->latitude . ',lng:' . $location->longitude . '}';
            }
        }
        return $locations;
//        return parent::toArray($request);
    }
}
