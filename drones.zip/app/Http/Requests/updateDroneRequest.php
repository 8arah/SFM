<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class updateDroneRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'mac'=>'required|string|min:10|unique:drones,mac,'.$this->id,
            'start_end_point_id'=>'required|numeric|exists:start_end_points,id',
            'weight'=>'sometimes|numeric|max:3000|nullable',
            'buttery'=>'sometimes|numeric|min:0|max:100|nullable',
            'heat'=>'sometimes|numeric|min:0|max:100|nullable',
        ];
    }
}
