<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StartEndPoint extends Model
{
    protected $fillable = ['lat','lng','name','status'];
    public function drone(){
        return $this->hasOne(Drone::class,'start_end_point_id','id');
    }
    public function getOwnDroneAttribute(){
        return $this->drone ? '<a>'.$this->drone->mac.'</a>' : '';
    }
    public function getStartingPointAttribute(){
        return '<a class="btn default" data-toggle="modal" href="#large" onclick="ShowStartingPoint(\''.$this->latitude.'\',\''.$this->longitude.'\')">view stationary point</a>';
    }
    public function getLatitudeAttribute(){
        return $this->lat ? $this->lat : '21.543333';
    }
    public function getLongitudeAttribute(){
        return $this->lng ? $this->lng : '39.172779';
    }
    public function getDeleteButtonAttribute(){
        return '<a href="#!" id="sample_editable_1_new" class="btn red" onclick="deleteItem(this,\''.route('start_points.destroy',$this->id).'\')">
                                            <i class="fa fa-trash"></i>
                                        </a>';
    }
}
