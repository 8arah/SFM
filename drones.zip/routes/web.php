<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['role_check'])->group(function () {

    Route::resource('/drones','DroneController')->except('index');
    Route::get('/dronesIndex/{trigger?}','DroneController@index')->name('drones.index');
    Route::get('/dronesLiveMap','DroneController@liveMap')->name('drones.liveMap');
    Route::get('/dronesLiveMapView','DroneController@dronesLiveMapView')->name('drones.dronesLiveMapView');
    Route::get('/dronePaths/{drone}','DroneController@dronePaths')->name('drones.paths');
    Route::get('/addNewPath/{drone}/{path}/{lat}/{lng}','DroneController@addNewPath');
    Route::resource('/start_points','startPointController');
    Route::resource('/end_points','endPointController');

//Route::get('/register', function(){});

});
Route::get('/home', function (){
    if(!\Illuminate\Support\Facades\Auth::user()->role) {
        return redirect('/dronesIndex');
    }else{
        return redirect('/orders');
    }
})->name('home');

Auth::routes();

Route::resource('/orders','ordersController');
Route::get('/order_history','ordersController@history')->name('orders.history');
Route::get('/order_stop/{path_id}','ordersController@stop')->name('orders.stop');
Route::get('/getOrderPath/{path_id}','ordersController@getOrderPath');

Route::get('/', function () {
    return view('landing_page.index');
});



