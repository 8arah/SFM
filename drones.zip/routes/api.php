<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/getAllPoints','api\apiController@getAllPoints');
Route::get('/getAllAvailableDrones','api\apiController@getAllAvailableDrones');
Route::get('/getWaitingOrders','api\apiController@getWaitingOrders');
Route::get('/getOnProcessingOrders','api\apiController@getOnProcessingOrders');
Route::get('/getDoneOrders','api\apiController@getDoneOrders');
Route::get('/getAvailableDrones','api\apiController@getAvailableDrones');
Route::post('/setPathForOrder/{path_id}/{drone_id}','api\apiController@setPathForOrder');
Route::get('/setOrderToBeDone/{path_id}/{station_id}','api\apiController@setOrderToBeDone');
Route::get('/getDroneOrderStatus/{path_id}','api\apiController@getDroneOrderStatus');
